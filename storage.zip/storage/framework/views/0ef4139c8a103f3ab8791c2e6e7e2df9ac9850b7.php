

<?php $__env->startSection('title', 'ADMIN'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>PROPIEDADES</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <div style="display: flex; justify-content: space-between; align-items: center;">

                        <span id="card_title">
                            <?php echo e(__('Propiedades')); ?>

                        </span>

                         <div class="float-right">
                            <a href="<?php echo e(route('propiedades.create')); ?>" class="btn btn-primary btn-sm float-right"  data-placement="left">
                              <?php echo e(__('NUEVO')); ?>

                            </a>
                          </div>
                    </div>
                </div>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="thead">
                                <tr>
                                    <th>No</th>
                                    
                                    <th>Manzana</th>
                                    <th>Lote</th>
                                    <th>Zona</th>
                                    
                                    <th>DNI Cliente</th>
                                    <th>Categoria</th>
                                    <th>Estado</th>
                                    <th>Fecha Inscripcion</th>
                                    <th>Fecha Adeudo</th>

                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $propiedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propiedade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$i); ?></td>
                                        
                                        <td><?php echo e(($propiedade->manzana)); ?></td>
                                        <td><?php echo e($propiedade->lote); ?></td>
                                        <td><?php echo e($propiedade->zona); ?></td>
                                        
                                        <?php if($propiedade->cliente_id==null): ?>
                                        <td class="text-danger">No tiene propietario</td>
                                        <?php else: ?>
                                        <td><?php echo e($propiedade->cliente->nombre); ?></td>
                                        <?php endif; ?>

                                        <?php if($propiedade->categoria_id==null): ?>
                                        <td class="text-danger">No tiene una categoria asignada</td>
                                        <?php else: ?>
                                        <td><?php echo e($propiedade->categoria->descripcion); ?></td>
                                        <?php endif; ?>
                                        
                                            <?php if($propiedade->estado==1): ?>
                                            <td class="text-success">ACTIVO</td>
                                            <?php else: ?>
                                            <td class="text-danger">INACTIVO</td>
                                            <?php endif; ?>
                                        

                                        <td><?php echo e($propiedade->fecha_inscripcion); ?></td>
                                        <td><?php echo e($propiedade->fecha_adeudo); ?></td>

                                        <td>
                                            <form action="<?php echo e(route('propiedades.destroy',$propiedade->id)); ?>" method="POST">
                                                <a class="btn btn-sm btn-primary " href="<?php echo e(route('propiedades.show',$propiedade->id)); ?>"><i class="fa fa-fw fa-eye"></i> DETALLES</a>
                                                <a class="btn btn-sm btn-success" href="<?php echo e(route('propiedades.edit',$propiedade->id)); ?>"><i class="fa fa-fw fa-edit"></i> EDITAR</a>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> Eliminar</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo $propiedades->links(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JASSC2023\resources\views/propiedade/index.blade.php ENDPATH**/ ?>