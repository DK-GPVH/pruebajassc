

<?php $__env->startSection('title', 'ADMIN'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><strong>MANZANA:</strong><?php echo e($propiedade->manzana ?? 'Show Propiedade'); ?><br><strong>LOTE :</strong><?php echo e($propiedade->lote ?? 'Show Propiedade'); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="float-left">
                        <span class="card-title">DETALLES PROPIEDAD</span>
                    </div>
                    <div class="float-right">
                        <a class="btn btn-primary" href="<?php echo e(route('propiedades.index')); ?>"> Regresar</a>
                    </div>
                </div>

                <div class="card-body">
                    
                    <div class="form-group">
                        <strong>Manzana:</strong>
                        <?php echo e($propiedade->manzana); ?>

                    </div>
                    <div class="form-group">
                        <strong>Lote:</strong>
                        <?php echo e($propiedade->lote); ?>

                    </div>
                    <div class="form-group">
                        <strong>Zona:</strong>
                        <?php echo e($propiedade->zona); ?>

                    </div>
                    <div class="form-group">
                        <strong>Nrodesuministro:</strong>
                        <?php echo e($propiedade->nrodesuministro); ?>

                    </div>
                    <?php if($propiedade->cliente_id==null): ?>
                    <div class="form-group">
                        <strong>Cliente :</strong>
                        <a class="text-danger">No tiene propietario</a></div>
                    <?php else: ?>
                    <div class="form-group">
                        <strong>Cliente:</strong>
                        <?php echo e($propiedade->cliente->nombre); ?>

                        <?php echo e($propiedade->cliente->apellidop); ?>

                        <?php echo e($propiedade->cliente->apellidom); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($propiedade->categoria_id==null): ?>
                    <div class="form-group">
                    <strong>Categoria :</strong>
                     <a class="text-danger">No tiene una categoria asignada</a> 
                    </div>
                    <?php else: ?>
                    <div class="form-group">
                        <strong>Categoria :</strong>
                        <?php echo e($propiedade->categoria->descripcion); ?>

                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <strong>Estado:</strong>
                        <?php if($propiedade->estado==1): ?>
                        <a class="text-success">ACTIVO</a>
                        <?php else: ?>
                        <a class="text-danger">INACTIVO</a>
                        <?php endif; ?>
                        
                        
                    </div>
                    <div class="form-group">
                        <strong>Fecha Inscripcion:</strong>
                        <?php echo e($propiedade->fecha_inscripcion); ?>

                    </div>
                    <div class="form-group">
                        <strong>Fecha Adeudo:</strong>
                        <?php echo e($propiedade->fecha_adeudo); ?>

                    </div>
 
                </div>

                    
                </div> 
                <strong>DEUDAS : </strong>
                <?php for($fechadeuda=\Carbon\Carbon::parse($propiedade->fecha_adeudo);$fechaactual>$fechadeuda;$fechadeuda): ?>
                     <div  class="card bg-secondary">
                        <div style="margin:0.5em;">
                            <strong>MES CORRESPONDIENTE:</strong>
                            <div><?php echo e(strtoupper($fechadeuda->locale('es')->monthName)); ?></div>   
                            <strong> FECHA A PAGAR: </strong>
                            <div><?php echo e($fechadeuda->addMonths(1)->format('Y-m-d')); ?></div>   
                        </div>
                     </div>     
                <?php endfor; ?> 
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JASSC2023\resources\views/propiedade/show.blade.php ENDPATH**/ ?>