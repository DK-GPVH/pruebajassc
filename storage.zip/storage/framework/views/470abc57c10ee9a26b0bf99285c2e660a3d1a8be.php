<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('manzana')); ?>

            <?php echo e(Form::text('manzana', $propiedade->manzana, ['class' => 'form-control' . ($errors->has('manzana') ? ' is-invalid' : ''), 'placeholder' => 'Manzana'])); ?>

            <?php echo $errors->first('manzana', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('lote')); ?>

            <?php echo e(Form::text('lote', $propiedade->lote, ['class' => 'form-control' . ($errors->has('lote') ? ' is-invalid' : ''), 'placeholder' => 'Lote'])); ?>

            <?php echo $errors->first('lote', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('zona')); ?>

            <?php echo e(Form::text('zona', $propiedade->zona, ['class' => 'form-control' . ($errors->has('zona') ? ' is-invalid' : ''), 'placeholder' => 'Zona'])); ?>

            <?php echo $errors->first('zona', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('nrodesuministro')); ?>

            <?php echo e(Form::text('nrodesuministro', $propiedade->nrodesuministro, ['class' => 'form-control' . ($errors->has('nrodesuministro') ? ' is-invalid' : ''), 'placeholder' => 'Nrodesuministro'])); ?>

            <?php echo $errors->first('nrodesuministro', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('DNI Cliente')); ?>

            <?php echo e(Form::select('cliente_id', $clientes,$propiedade->cliente_id, ['class' => 'form-control' . ($errors->has('cliente_id') ? ' is-invalid' : ''), 'placeholder' => 'DNI Cliente'])); ?>

            <?php echo $errors->first('cliente_id', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Categoria')); ?>

            <?php echo e(Form::select('categoria_id', $categorias,$propiedade->categoria_id, ['class' => 'form-control' . ($errors->has('categoria_id') ? ' is-invalid' : ''), 'placeholder' => 'Categoria'])); ?>

            <?php echo $errors->first('categoria_id', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('estado')); ?>

            <br>
            <?php echo e(Form::label('activo')); ?>

            <?php echo e(Form::radio('estado','1',$propiedade->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : '')])); ?>

            <?php echo e(Form::label('inactivo')); ?>

            <?php echo e(Form::radio('estado','0',$propiedade->estado, ['class' => 'form-control' . ($errors->has('estado') ? ' is-invalid' : '')])); ?>

            <?php echo $errors->first('estado', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('fecha_inscripcion')); ?>

            <?php echo e(Form::date('fecha_inscripcion', $propiedade->fecha_inscripcion, ['class' => 'form-control' . ($errors->has('fecha_inscripcion') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Inscripcion'])); ?>

           
            <?php echo $errors->first('fecha_inscripcion', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('fecha_adeudo')); ?>

            <?php echo e(Form::date('fecha_adeudo', $propiedade->fecha_adeudo, ['class' => 'form-control' . ($errors->has('fecha_adeudo') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Adeudo'])); ?>

            <?php echo $errors->first('fecha_adeudo', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\JASSC2023\resources\views/propiedade/form.blade.php ENDPATH**/ ?>